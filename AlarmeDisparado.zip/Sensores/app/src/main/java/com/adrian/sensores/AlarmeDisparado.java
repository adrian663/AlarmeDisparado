package com.adrian.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AlarmeDisparado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarme_disparado);
    }
}